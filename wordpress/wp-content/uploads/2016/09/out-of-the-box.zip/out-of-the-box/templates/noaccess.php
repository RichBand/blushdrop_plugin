<div id='OutoftheBox'>
  <div class='OutoftheBox list-container noaccess'>
    <img src="<?php echo OUTOFTHEBOX_ROOTPATH; ?>/css/clouds/cloud_shield_128.png" data-src-retina="<?php echo OUTOFTHEBOX_ROOTPATH; ?>/css/clouds/cloud_shield_256.png">
    <p><?php echo __("Your account doesn't have the right permissions to use this", 'outofthebox') . ". " . __("Contact the webmaster if you would like to have access", 'outofthebox'); ?>.</p>
  </div>
</div>
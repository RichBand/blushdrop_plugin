<?php

/**
 * View for Form Builder
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="rp_wccf_fb"></div>